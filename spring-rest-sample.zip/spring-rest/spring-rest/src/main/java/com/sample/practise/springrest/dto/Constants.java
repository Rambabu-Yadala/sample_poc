package com.sample.practise.springrest.dto;

public class Constants {
	
	public static final String BUY_1_GET_1 =  "BUY_1_GET_1";
	public static final String FLAT_DISCOUNT =  "FLAT_DISCOUNT";
	public static final String PRICE_DISCOUNT =  "PRICE_DISCOUNT";

}
