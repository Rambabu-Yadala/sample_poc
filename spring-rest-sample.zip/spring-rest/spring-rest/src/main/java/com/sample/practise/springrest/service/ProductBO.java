package com.sample.practise.springrest.service;

public class ProductBO {

}
